1. type cd filepath/Interest_Site into console
2. type node server.js
3. lessc LESS/styles.less build/style.css (I haven't tested doing it this way)
4. Open website
